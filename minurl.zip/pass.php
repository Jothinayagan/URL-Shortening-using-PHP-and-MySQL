<?php

$user = "webville123";
$pass = "admin";
$salt = "skkgf4dfg!";
$enc_pass = md5($pass);
echo "$enc_pass";
?>