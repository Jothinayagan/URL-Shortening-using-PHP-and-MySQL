<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
     
        ?>
		<a href="viewusers.php">View Users</a>
        	<a href="viewurls.php">View Urls</a>
			 <a href="viewlog.php">View Logs</a>
           <a href="../logout.php">Logout</a>  
	   
    </body>
</html>
