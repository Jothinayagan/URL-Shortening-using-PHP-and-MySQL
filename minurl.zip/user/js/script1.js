$(document).ready(function() {
$('#languages').multiselect({
nonSelectedText: 'Select Language'
});
});